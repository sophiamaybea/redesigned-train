import React from "react";
import { getGreeting, getSeason } from "@/lib/gardenUtils";

const STAGES = [
  { stage: "seedling", eyebrow: "New notions", label: "Seedlings", colour: "#d7b85b", tilt: "-2.5deg", note: "FIRST DRAFTS" },
  { stage: "growing", eyebrow: "In the works", label: "Growing", colour: "#ed8b45", tilt: "1.8deg", note: "MESSY MIDDLES" },
  { stage: "bloom", eyebrow: "Ready to read", label: "In bloom", colour: "#d75d43", tilt: "-1.2deg", note: "FINISHED PIECES" },
  { stage: "resting", eyebrow: "For later", label: "Resting", colour: "#8b9d72", tilt: "2.8deg", note: "THE BACK DRAWER" },
];

export default function OrbitalHero({ pieces = [], activeStage, onStageClick }) {
  const counts = { seedling: 0, growing: 0, bloom: 0, resting: 0 };
  pieces.forEach((piece) => { counts[piece.stage] = (counts[piece.stage] || 0) + 1; });
  const day = new Date().toLocaleDateString("en-US", { weekday: "long" });

  return (
    <section className="studio-hero" aria-labelledby="studio-hero-title">
      <div className="studio-hero__paper" aria-hidden="true" />
      <header className="studio-hero__masthead">
        <span>THE GARDEN WRITING STUDIO</span>
        <span className="studio-hero__address">MANHATTAN · {getSeason()}</span>
      </header>

      <div className="studio-hero__intro">
        <p className="studio-hero__kicker">{day} · {getGreeting()}</p>
        <h1 id="studio-hero-title">Come up and write.</h1>
        <p className="studio-hero__dek">A private room for unfinished sentences,<br className="hidden sm:block" /> unruly pages and very serious play.</p>
      </div>

      <div className="studio-window" aria-hidden="true">
        <div className="studio-window__sky">
          <span className="studio-window__moon" />
          <svg viewBox="0 0 500 170" preserveAspectRatio="none" className="studio-window__city">
            <path d="M0 170V105h28V79h13v26h31V63h31v42h17V44h42v61h20V86h38v19h18V68h24v37h26V51h13V25h12v26h13v54h31V73h42v32h20V57h31v48h18V83h31v22h29v65Z" />
            <g className="studio-window__lights"><path d="M83 76h7v10h-7zm50-17h7v10h-7zm20 18h7v10h-7zm92-2h7v10h-7zm75-7h7v10h-7zm63 16h7v10h-7zm68-13h7v10h-7z" /></g>
          </svg>
          <span className="studio-window__bar studio-window__bar--v" />
          <span className="studio-window__bar studio-window__bar--h" />
        </div>
      </div>

      <div className="studio-shelf" aria-label="Your writing shelves">
        <div className="studio-shelf__ledge studio-shelf__ledge--top" aria-hidden="true" />
        <div className="studio-shelf__books">
          {STAGES.map((item, index) => {
            const selected = activeStage === item.stage;
            const dimmed = activeStage && !selected;
            return (
              <button type="button" key={item.stage}
                className={`writing-book writing-book--${index + 1}${selected ? " is-selected" : ""}${dimmed ? " is-dimmed" : ""}`}
                style={{ "--book-colour": item.colour, "--book-tilt": item.tilt }}
                onClick={() => onStageClick(item.stage)} aria-pressed={selected}
                aria-label={`${item.label}: ${counts[item.stage]} pieces`}>
                <span className="writing-book__scribble" aria-hidden="true">✶</span>
                <span className="writing-book__eyebrow">{item.eyebrow}</span>
                <strong>{item.label}</strong><span className="writing-book__rule" />
                <span className="writing-book__count">{counts[item.stage]}</span>
                <span className="writing-book__note">{item.note}</span>
              </button>
            );
          })}
          <div className="shelf-pumpkin" aria-hidden="true"><span className="shelf-pumpkin__stem" /><span className="shelf-pumpkin__body" /></div>
          <div className="shelf-cup" aria-hidden="true">PENCILS</div>
        </div>
        <div className="studio-shelf__ledge" aria-hidden="true" />
        <p className="studio-shelf__instruction">Choose a notebook to see what is growing</p>
      </div>

      <div className="studio-hero__doodle studio-hero__doodle--left" aria-hidden="true">new york,<br />new paragraph</div>
      <div className="studio-hero__doodle studio-hero__doodle--right" aria-hidden="true">upstairs<br />&amp; unwatched ↗</div>
    </section>
  );
}
