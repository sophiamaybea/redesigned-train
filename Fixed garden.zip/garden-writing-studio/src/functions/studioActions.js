import { base44 } from "@/api/base44Client";

/**
 * Typed-by-convention client wrapper for the Studio backend function.
 * Keeping the invocation here gives every editorial screen one stable import.
 */
export function studioActions(payload) {
  return base44.functions.invoke("studioActions", payload);
}
